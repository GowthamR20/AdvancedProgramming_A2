package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.IdGeneration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class JobPostController implements Initializable {
    @FXML
    private static String studentId;
    public Label jobOperationLabel;
    @FXML
    public TextArea jobSummaryTextField;
    @FXML
    public Button jobSaleButton;
    @FXML
    public TextField jobName;
    @FXML
    public TextField jobDescription;
    @FXML
    public TextField jobProposedPrice;
    @FXML
    public Label validationMessage;
    @FXML
    public ImageView jobPhoto;

    private static String jobId;
    private boolean canSave = false;
    private FileChooser fileChooser;
    private File filePath;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        jobOperationLabel.setText("Create Job Post");
        IdGeneration ig = new IdGeneration();
        jobId = ig.generateId("Job");
    }

    public void setLoginId(String studentId) {
        this.studentId = studentId;
    }

    @FXML
    public void saveNewJob(ActionEvent actionEvent) {
        StringBuilder sb = new StringBuilder("\t\tYour Job \n");
        try {
            int proposedPrice = Integer.parseInt(jobProposedPrice.getText());
            if (proposedPrice > 0) {
                canSave = true;
            }
        } catch (Exception e) {
            canSave = false;
        }
        if (canSave) {
            sb.append("\nPost Id: ").append(jobId)
                    .append("\nCreator id: ").append(studentId)
                    .append("\nJob Name: ").append(jobName.getText())
                    .append("\nSale Description: ").append(jobProposedPrice.getText());
            jobSummaryTextField.setText(sb.toString());
            resetEntries(actionEvent);
//            Stage s = (Stage) ((Node) (actionEvent).getSource()).getScene().getWindow();
//            s.close();
        } else {
            validationMessage.setText("Some input are not valid input");
        }
    }

    @FXML
    public void resetEntries(ActionEvent actionEvent) {
        jobName.setText("");
        jobDescription.setText("");
        jobProposedPrice.setText("");
    }

    @FXML
    public void chooseImageJob(ActionEvent actionEvent) {
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        this.filePath = fileChooser.showOpenDialog(stage);
        File imageFile = new File(filePath.toString());
        imageFile.renameTo(new File("E:\\MIT\\Semester 2\\Advanced Programming\\AP_Assignment2\\src\\images\\" + jobId + ".jpg"));
        try {
            BufferedImage bi = ImageIO.read(filePath);
            Image image = SwingFXUtils.toFXImage(bi, null);
            jobPhoto.setImage(image);
        } catch (IOException e) {
        }
    }


}
