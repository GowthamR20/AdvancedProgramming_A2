package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.IdGeneration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SalePostController implements Initializable {
    @FXML
    public TextArea saleSummaryTextField;
    @FXML
    public Button saveSaleButton;
    @FXML
    public TextField saleName;
    @FXML
    public TextField saleDescription;
    @FXML
    public TextField saleAskingPrice;
    @FXML
    public TextField saleMinimumRaise;
    @FXML
    public Label validationMessage;
    @FXML
    public ImageView salePhoto;
    @FXML
    public Label saleOperationLabel;

    private String saleId;
    private static String studentId;
    boolean canSave = false;
    private FileChooser fileChooser;
    private File filePath;

    @FXML
    public void saveNewSale(ActionEvent actionEvent) {
        StringBuilder sb = new StringBuilder("\t\tYour Sale \n");
        try {
            int askingPrice = Integer.parseInt(saleAskingPrice.getText());
            int minimumRaise = Integer.parseInt(saleMinimumRaise.getText());
            if (askingPrice > 0 && minimumRaise > 0) {
                canSave = true;
            }
        } catch (Exception e) {
            canSave = false;
        }
        if (canSave) {
            sb.append("\nPost Id: ").append(saleId)
                    .append("\nCreator id: ").append(studentId)
                    .append("\n Sale Name").append(saleName.getText())
                    .append("\nSale Description: ").append(saleDescription.getText())
                    .append("\nSale Asking Price: ").append(saleAskingPrice.getText())
                    .append("\nSale Minimum Raise: ").append(saleMinimumRaise.getText());
            saleSummaryTextField.setText(sb.toString());
            resetEntries(actionEvent);
//            Stage s= (Stage) ((Node) (actionEvent).getSource()).getScene().getWindow();
//            s.close();
        } else {
            validationMessage.setText("Some input are not valid input");
        }
    }

    @FXML
    public void chooseImageSale(ActionEvent actionEvent) {
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        this.filePath = fileChooser.showOpenDialog(stage);
        File imageFile = new File(filePath.toString());
        imageFile.renameTo(new File("E:\\MIT\\Semester 2\\Advanced Programming\\AP_Assignment2\\src\\images\\" + saleId + ".jpg"));
        try {
            BufferedImage bi = ImageIO.read(filePath);
            Image image = SwingFXUtils.toFXImage(bi, null);
            salePhoto.setImage(image);
        } catch (IOException e) {
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        saleOperationLabel.setText("Create Sale Post");
        IdGeneration ig = new IdGeneration();
        saleId = ig.generateId("Sale");
    }

    public void resetEntries(ActionEvent actionEvent) {
        saleName.setText("");
        saleDescription.setText("");
        saleAskingPrice.setText("");
        saleMinimumRaise.setText("");

    }

    public void setLoginId(String studentId) {
        this.studentId = studentId;
    }
}
