package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.IdGeneration;
import main.ValidateDate;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import java.util.ResourceBundle;

public class EventPostController implements Initializable {

    @FXML
    public VBox createEventBox;
    @FXML
    public VBox createEventSummaryBox;
    @FXML
    public Label eventOperationLabel;
    @FXML
    public TextField eventName;
    @FXML
    public TextField eventDescription;
    @FXML
    public TextField eventVenue;
    @FXML
    public TextField eventDate;
    @FXML
    public TextField eventMaxCapacity;
    @FXML
    public TextArea eventSummaryTextField;
    @FXML
    public Label validationMessage;
    @FXML
    public Button saveEventButton;
    @FXML
    public Label postNameId;
    @FXML
    public ImageView eventPhoto;
    private String eventId;
    private FileChooser fileChooser;
    private File filePath;
    private static String studentId;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        eventOperationLabel.setText("Create Event Post");
        IdGeneration ig = new IdGeneration();
        eventId = ig.generateId("Event");
    }

    @FXML
    public void resetEntries(ActionEvent actionEvent) {
        eventName.setText("");
        eventDescription.setText("");
        eventVenue.setText("");
        eventDate.setText("");
        eventMaxCapacity.setText("");
    }

    @FXML
    public void saveNewEvent(ActionEvent actionEvent) throws IOException {

        ValidateDate vD = new ValidateDate();
        boolean canSave = false;
        int maxCapacity = 0;
        try {
            maxCapacity = Integer.parseInt(eventMaxCapacity.getText());
            if (maxCapacity > 0) {
                canSave = true;
            }
        } catch (Exception e) {
            canSave = false;
        }

        if (vD.validateDate(eventDate.getText()) && canSave) {
            if (!(eventName.getText().equals("") && eventDescription.getText().equals("") && eventVenue.getText().equals(""))) {
                validationMessage.setText("");
                StringBuilder sb = new StringBuilder("\t\tYour Event\n");

                sb.append("\nPost Id: ").append(eventId)
                        .append("\nCreator id: ").append(studentId)
                        .append("\nEvent Name: ").append(eventName.getText())
                        .append("\nEvent Description: ").append(eventDescription.getText())
                        .append("\nEvent Date: ").append(eventDate.getText())
                        .append("\nEVent Venue: ").append(eventVenue.getText())
                        .append("\nEvent Max-Capacity: ").append(eventMaxCapacity.getText());
                eventSummaryTextField.setText(sb.toString());
                // Save to DB and close window
                validationMessage.setText("Event Successfully Created and saved");
                resetEntries(actionEvent);
//                Stage s= (Stage) ((Node) (actionEvent).getSource()).getScene().getWindow();
//                s.close();
            } else {
                validationMessage.setText("All Fields are mandatory");
            }
        } else {
            validationMessage.setText("Wrong Input Provided");
        }
    }

    @FXML
    public void chooseImage(ActionEvent actionEvent) {
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image");
        this.filePath = fileChooser.showOpenDialog(stage);
        File imageFile = new File(filePath.toString());
        imageFile.renameTo(new File("E:\\MIT\\Semester 2\\Advanced Programming\\AP_Assignment2\\src\\images\\" + eventId + ".jpg"));
        try {
            BufferedImage bi = ImageIO.read(filePath);
            Image image = SwingFXUtils.toFXImage(bi, null);
            eventPhoto.setImage(image);
        } catch (IOException e) {
        }
    }

    public void setLoginId(String studentId) {
        this.studentId = studentId;
    }
}