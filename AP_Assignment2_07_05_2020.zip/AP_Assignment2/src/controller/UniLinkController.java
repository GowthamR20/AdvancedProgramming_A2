package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UniLinkController implements Initializable {
    @FXML
    public ChoiceBox<String> typeFilter;
    @FXML
    public ChoiceBox<String> statusFilter;
    @FXML
    public ChoiceBox<String> creatorFilter;
    @FXML
    public Label welcomeLabel;
    @FXML
    public Button logoutButton;

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    private static String studentId;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        welcomeLabel.setText("Welcome " + getStudentId() + "!");
        typeFilter.getItems().add("All Post");
        typeFilter.getItems().add("Event Post");
        typeFilter.getItems().add("Sale Post");
        typeFilter.getItems().add("Job Post");
        typeFilter.setValue("All Post");
        typeFilter.getSelectionModel().selectedItemProperty().addListener((v, oldVal, newVal) -> {
            System.out.println("Chosen filter Type: " + newVal);
        });

        statusFilter.getItems().add("All Post");
        statusFilter.getItems().add("Open Post");
        statusFilter.getItems().add("Closed Post");
        statusFilter.setValue("All Post");
        statusFilter.getSelectionModel().selectedItemProperty().addListener((v, oldVal, newVal) -> {
            System.out.println("Chosen Status Type: " + newVal);
        });

        creatorFilter.getItems().add("My Post");
        creatorFilter.getItems().add("All Post");
        creatorFilter.setValue("My Post");
        creatorFilter.getSelectionModel().selectedItemProperty().addListener((v, oldVal, newVal) -> {
            System.out.println("Chosen Creator Type: " + newVal);
        });
    }

    @FXML
    public void developerDetail(ActionEvent actionEvent) throws IOException {
        Stage mainStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/view/DeveloperDetail_View.fxml"));
        mainStage.setTitle("Developer Detail");
        mainStage.setScene(new Scene(root));
        mainStage.show();
    }

    @FXML
    public void importPostToFile(ActionEvent actionEvent) {
        System.out.println("Importing to file");
    }

    @FXML
    public void exportPostToFile(ActionEvent actionEvent) {
        System.out.println("Exporting to file");
    }

    @FXML
    public void eventPost(ActionEvent actionEvent) throws IOException {
        FXMLLoader eventLoader = new FXMLLoader(getClass().getResource("/view/EventPost_View.fxml"));
        Parent eventRoot = eventLoader.load();
        EventPostController eventPostController = eventLoader.getController();
        eventPostController.setLoginId(getStudentId());

        Parent root = FXMLLoader.load(getClass().getResource("/view/EventPost_View.fxml"));
        Stage eventPostWindow = new Stage();
        eventPostWindow.initModality(Modality.APPLICATION_MODAL);
        eventPostWindow.setTitle("Event Post");
        eventPostWindow.setScene(new Scene(root));
        eventPostWindow.showAndWait();
    }

    public void setLoginId(String loginId) {
        setStudentId(loginId);
    }

    @FXML
    public void salePost(ActionEvent actionEvent) throws IOException {
        FXMLLoader eventLoader = new FXMLLoader(getClass().getResource("/view/SalePost_View.fxml"));
        Parent eventRoot = eventLoader.load();
        SalePostController salePostController = eventLoader.getController();
        salePostController.setLoginId(getStudentId());

        Parent root = FXMLLoader.load(getClass().getResource("/view/SalePost_View.fxml"));
        Stage salePostWindow = new Stage();
        salePostWindow.initModality(Modality.APPLICATION_MODAL);
        salePostWindow.setTitle("Sale Post");
        salePostWindow.setScene(new Scene(root));
        salePostWindow.showAndWait();
    }

    @FXML
    public void jobPost(ActionEvent actionEvent) throws IOException {
        FXMLLoader eventLoader = new FXMLLoader(getClass().getResource("/view/JobPost_View.fxml"));
        Parent eventRoot = eventLoader.load();
        JobPostController jobPostController = eventLoader.getController();
        jobPostController.setLoginId(getStudentId());

        Parent root = FXMLLoader.load(getClass().getResource("/view/JobPost_View.fxml"));
        Stage salePostWindow = new Stage();
        salePostWindow.initModality(Modality.APPLICATION_MODAL);
        salePostWindow.setTitle("Job Post");
        salePostWindow.setScene(new Scene(root));
        salePostWindow.showAndWait();
    }

    @FXML
    public void logoutUniLink(ActionEvent actionEvent) throws IOException {
        Stage s = (Stage) ((Node) (actionEvent).getSource()).getScene().getWindow();
        System.out.println("Save to DB and close");
        s.close();
        System.out.println("Login Page");
        Parent root = FXMLLoader.load(getClass().getResource("/view/Login_View.fxml"));
        s.setTitle("Login Page");
        s.setScene(new Scene(root));
        s.show();
    }
}
