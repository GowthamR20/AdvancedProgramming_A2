package main;

import javax.swing.tree.ExpandVetoException;

public class IdGeneration {

    private static String EVENT_PREFIX = "EVE";
    private static String SALE_PREFIX = "SAL";
    private static String JOB_PREFIX = "JOB";
    private static int eventNo = 0;
    private static int saleNo = 0;
    private static int jobNo = 0;
    private static String postid;
    private static String saleid;
    private static String jobid;

    public static String generateId(String postName) {
        if (postName.equalsIgnoreCase("Event")) {
            postid = EVENT_PREFIX + String.format("%03d", eventNo++);
            return postid;
        } else if (postName.equalsIgnoreCase("Sale")) {
            saleid = SALE_PREFIX + String.format("%03d", saleNo++);
            return saleid;
        } else {
            jobid = JOB_PREFIX + String.format("%03d", jobNo++);
            return jobid;
        }
    }
}
