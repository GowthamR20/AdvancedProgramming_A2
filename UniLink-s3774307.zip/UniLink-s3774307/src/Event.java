
public class Event extends Post {

	private String venue;
	private String date;
	private int capacity;
	private int attendee_count = -1;
	private String attendee_list = "";

	public Event(String id, String title, String description, String creator_id, String status, String venue,
			String date, int capacity, int attendee_count) {
		super(id, title, description, creator_id, status);
		setVenue(venue);
		setDate(date);
		setCapacity(capacity);
		setAttendee_count();
	}

	public String getPostDetails() {
		return super.getPostDetails() + "\nVenue: " + getVenue() + "\nDate: " + getDate() + "\nCapacity: "
				+ getCapacity() + "\nAttendees: " + getAttendee_count();
	}

	public boolean handleReply(Reply reply) {
		if ((capacity > attendee_count) && (reply.getValue() == 1)
				&& (!attendee_list.contains(reply.getResponder_id()))) {
			super.setReplies(reply);
			setAttendee_list(reply.getResponder_id());
			setAttendee_count();
			if (capacity == attendee_count)
				setStatus("CLOSED");
			return true;
		} else if ((attendee_list.contains(reply.getResponder_id()))) {
			return true;
		}
		return false;
	}

	public String getReplyDetails() {
		String postDetails = getPostDetails();
		if (attendee_list.isEmpty())
			postDetails = postDetails + "\nAttendee List: Empty";
		else
			postDetails = postDetails + "\nAttendee List: " + getAttendee_list();
		return postDetails;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getAttendee_count() {
		return attendee_count;
	}

	public void setAttendee_count() {
		this.attendee_count++;
	}

	public String getAttendee_list() {
		return attendee_list;
	}

	public void setAttendee_list(String attendee_list) {
		if (this.attendee_list.isEmpty())
			this.attendee_list += attendee_list;
		else
			this.attendee_list += "," + attendee_list;
	}

}
