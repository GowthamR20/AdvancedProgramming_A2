
public class Reply {

	private String post_id;
	private double value;
	private String responder_id;
	
	public Reply(String post_id, double value, String responder_id) {
		setPost_id(post_id);
		setValue(value);
		setResponder_id(responder_id);
	}
	
	public String getPost_id() {
		return post_id;
	}

	public void setPost_id(String post_id) {
		this.post_id = post_id;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public String getResponder_id() {
		return responder_id;
	}

	public void setResponder_id(String responder_id) {
		this.responder_id = responder_id;
	}

}
