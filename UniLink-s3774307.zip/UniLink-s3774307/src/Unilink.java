import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Unilink {

	private static String username;
	private static Scanner sc; // = new Scanner(System.in);
	private static ArrayList<Post> posts = new ArrayList<Post>();
	private static Post post = null;
	private static String id;
	private static String name;
	private static String description;
	private static String venue;
	private static String date;
	private static int eventNo = 1;
	private static int saleNo = 1;
	private static int jobNo = 1;
	private static int capacity;
	private static double ask_price;
	private static double min_raise;
	private static double proposed_price;

	private static boolean input_mismatch;
	private static int main_choice;
	private static int menu_choice = 0;

	public static void createNewPost(int choice) throws InputMismatchException {
		sc = new Scanner(System.in);
		if (choice == 1)
			System.out.println("Enter details of the event below: ");
		else if (choice == 2)
			System.out.println("Enter details of the item below: ");
		else if (choice == 3)
			System.out.println("Enter details of the job below: ");

		if (choice >= 1 && choice <= 3) {
			System.out.println("Name: ");
			do {
				name = sc.nextLine();
				if (name.isEmpty())
					System.out.println("Name cannot be empty. Enter again: ");
			} while ((name.isEmpty()));

			System.out.println("Description: ");
			do {
				description = sc.nextLine();
				if (description.isEmpty())
					System.out.println("Description cannot be empty. Enter again: ");
			} while ((description.isEmpty()));
		}

		// Creating Event Post
		if (choice == 1) {
			System.out.println("Venue: ");
			do {
				venue = sc.nextLine();
				if (venue.isEmpty())
					System.out.println("Venue cannot be empty. Enter again: ");
			} while ((venue.isEmpty()));

			System.out.println("Date: ");
			do {
				date = sc.nextLine();
				if (date.isEmpty()) {
					System.out.println("Date cannot be empty. Enter again: ");
				} else if (!date.matches("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$")) {
					System.out.println("Date not valid. Enter again: ");
				}
			} while (!date.matches("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$") || date.isEmpty());

			System.out.println("Capacity: ");
			do {
				try {
					sc = new Scanner(System.in);
					do {
						capacity = sc.nextInt();
						if (capacity < 1)
							System.out.println("Invalid capacity. Enter again: ");
						input_mismatch = false;
					} while (capacity < 1);
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			id = "EVE" + String.format("%03d", eventNo);
			post = new Event(id, name, description, username, "OPEN", venue, date, capacity, 0);
			posts.add(post);
			System.out.println("\nSuccess! Your event has been created with id " + id + "\n");
			eventNo++;
		}

		// Creating Sale Post
		if (choice == 2) {
			System.out.println("Asking price: ");
			do {
				try {
					sc = new Scanner(System.in);
					do {
						ask_price = sc.nextDouble();
						if (ask_price < 0)
							System.out.println("Invalid price. Enter again: ");
						input_mismatch = false;
					} while (ask_price < 0);
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			System.out.println("Minimum raise: ");
			do {
				try {
					sc = new Scanner(System.in);
					do {
						min_raise = sc.nextDouble();
						if (min_raise < 0)
							System.out.println("Invalid raise. Enter again: ");
						input_mismatch = false;
					} while (min_raise < 0);
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			id = "SAL" + String.format("%03d", saleNo);
			post = new Sale(id, name, description, username, "OPEN", ask_price, min_raise);
			posts.add(post);
			System.out.println("\nSuccess! Your sale has been created with id " + id + "\n");
			saleNo++;
		}

		// Creating Job Post
		if (choice == 3) {
			System.out.println("Proposed price: ");
			do {
				try {
					sc = new Scanner(System.in);
					do {
						proposed_price = sc.nextDouble();
						if (proposed_price < 0)
							System.out.println("Invalid price. Enter again: ");
						input_mismatch = false;
					} while (proposed_price < 0);
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			id = "JOB" + String.format("%03d", jobNo);
			post = new Job(id, name, description, username, "OPEN", proposed_price, 0);
			posts.add(post);
			System.out.println("\nSuccess! Your job has been created with id " + id + "\n");
			jobNo++;
		}

		// HardCode Event Post
		if (choice == 4) {
			Reply reply;
			id = "EVE" + String.format("%03d", eventNo);
			post = new Event(id, "BBQ Party!", "Come make friends and enjoy the food!", "s1", "OPEN", "Bowen Street",
					"24/04/2020", 10, 3);

			reply = new Reply(id, 1.0, "s2");
			post.handleReply(reply);

			reply = new Reply(id, 1.0, "s4");
			post.handleReply(reply);

			reply = new Reply(id, 1.0, "s6");
			post.handleReply(reply);

			posts.add(post);
			eventNo++;
		}

		// HardCode Sale Post
		if (choice == 5) {
			Reply reply;
			id = "SAL" + String.format("%03d", saleNo);
			post = new Sale(id, "iPhone 6S Plus", "New phone. Good working condition. Used only for 3 months", "s3",
					"OPEN", 600.0, 100.0);
			reply = new Reply(id, 250, "s6");
			post.handleReply(reply);

			reply = new Reply(id, 450, "s9");
			post.handleReply(reply);

			posts.add(post);
			saleNo++;
		}

		// HardCode Job Post
		if (choice == 6) {
			Reply reply;
			id = "JOB" + String.format("%03d", jobNo);
			post = new Job(id, "Website Development", "Using shopify", "s9", "OPEN", 35.0, 0);
			reply = new Reply(id, 40.0, "s4");
			post.handleReply(reply);

			reply = new Reply(id, 25.0, "s4");
			post.handleReply(reply);

			reply = new Reply(id, 35.0, "s6");
			post.handleReply(reply);

			posts.add(post);
			jobNo++;
		}
	}

	public static void replyPost() {
		sc = new Scanner(System.in);
		System.out.println("Enter Post ID");
		String postID;
		do {
			postID = sc.nextLine();
			if (postID.isEmpty())
				System.out.println("Post ID cannot be empty. Enter again: ");
		} while (postID.isEmpty());

		double value = 0;
		int i;
		boolean found = false;

		for (i = 0; i < posts.size(); i++)
			if (posts.get(i).getId().equals(postID))
				found = true;
		if (found) {
			for (i = 0; i < posts.size(); i++) {
				if (posts.get(i).getCreator_id().equals(username) && posts.get(i).getId().equals(postID)) {
					System.out.println("Replying to your own post is invalid!");
				} else if (posts.get(i).getPostDetails().contains(postID)) {
					if (posts.get(i).getStatus().equals("CLOSED"))
						System.out.println("This post is already closed. Reply not accepted.");

					// Reply Event Post
					else if (posts.get(i) instanceof Event) {
						System.out.println("Are you attaneding or not (1- yes/ 0- no)");
						do {
							try {
								sc = new Scanner(System.in);
								do {
									value = sc.nextDouble();
									if (value > 1 || value < 0)
										System.out.println("Invalid input. Enter again.");
									input_mismatch = false;
								} while (value > 1 || value < 0);
							} catch (Exception e) {
								System.out.println("Invalid input. Enter again: ");
								input_mismatch = true;
							}
						} while (input_mismatch);

						Reply reply = new Reply(postID, (int) value, username);
						if (posts.get(i).getReplyDetails().contains(username)) {
							System.out.println("You have already registered to this event.");
							posts.set(i, posts.get(i));
						} else if (posts.get(i).handleReply(reply)) {
							System.out.println("Event registration accepted!");
							posts.set(i, posts.get(i));
						} else
							System.out.println("Event registration not completed!");
					}
					// Reply Sale Post
					else if (posts.get(i) instanceof Sale) {
						System.out.println("Enter your offer: ");
						do {
							try {
								sc = new Scanner(System.in);
								do {
									value = sc.nextDouble();
									if (value < 0)
										System.out.println("Invalid offer. Enter again: ");
									input_mismatch = false;
								} while (value < 0);
							} catch (Exception e) {
								System.out.println("Invalid input. Enter again: ");
								input_mismatch = true;
							}
						} while (input_mismatch);

						Reply reply = new Reply(postID, value, username);
						if (posts.get(i).getStatus().equals("CLOSED")) {
							System.out.println("Congratulations! the " + posts.get(i).getTitle()
									+ " has been sold to you.\n Please contact the owner "
									+ posts.get(i).getCreator_id() + " for more details");
						} else if (posts.get(i).handleReply(reply)) {
							System.out.println(
									"Your offer has been submitetd!\nHowever your offer is below the asking price.\nThe item is still on sale.");
							posts.set(i, posts.get(i));
						} else
							System.out.println("Offer not accepted!");
					}

					// Reply Job Post
					else if (posts.get(i) instanceof Job) {
						System.out.println("Enter your offer: ");
						do {
							try {
								sc = new Scanner(System.in);
								do {
									value = sc.nextDouble();
									if (value < 0)
										System.out.println("Invalid offer. Enter again: ");
									input_mismatch = false;
								} while (value < 0);
							} catch (Exception e) {
								System.out.println("Invalid input. Enter again: ");
								input_mismatch = true;
							}
						} while (input_mismatch);

						Reply reply = new Reply(postID, value, username);
						if (posts.get(i).handleReply(reply)) {
							System.out.println("Offer accepted");
						} else
							System.out.println("Offer not accepted!");
					}
				}
			}
		} else
			System.out.println("Invalid Post ID! Post not found.");
	}

	public static void closeDeletePost(int option) {
		sc = new Scanner(System.in);
		System.out.println("Enter post ID: ");
		String postID;
		do {
			postID = sc.nextLine();
			if (postID.isEmpty())
				System.out.println("Post ID cannot be empty. Enter again: ");
		} while (postID.isEmpty());
		String confirm;

		boolean task_completed = false;
		int i;
		for (i = 0; i < posts.size(); i++) {
			if (postID.equals(posts.get(i).getId())) {
				if (posts.get(i).getCreator_id().equals(username)) {
					if (option == 7 && posts.get(i).getStatus().equals("CLOSED")) {
						System.out.println("This post is already closed. Reply not accepted.");
						task_completed = true;
					} else {
						// Close Post
						if (option == 7) {
							int lowest = 0;
							double lowestvalue;
							System.out.println("Are you sure to close the post? (Y/N)");
							confirm = sc.next();
							if (confirm.toLowerCase().contains("y")) {
								posts.get(i).setStatus("CLOSED");
								System.out.println("Suceeded! Post " + posts.get(i).getId() + " is closed.");
								task_completed = true;
								if (posts.get(i) instanceof Job) {
									lowestvalue = 999999;
									for (int j = 0; j < post.getReplies().size(); j++) {
										
										if (lowestvalue < post.getReplies().get(j).getValue()) {
											lowestvalue = post.getReplies().get(j).getValue();
											lowest = j;
										}
									}
									System.out.println(
											"Job offered to " + post.getReplies().get(lowest).getResponder_id());
								}
							} else {
								System.out.println("Post not closed.");
								task_completed = true;
							}
						}
						// Delete Post
						else if (option == 8) {
							System.out.println("Are you sure to delete the post? (Y/N)");
							confirm = sc.next();
							if (confirm.toLowerCase().contains("y")) {
								System.out.println("Succeeded! Post " + posts.get(i).getId() + " is deleted.");
								posts.remove(i);
								task_completed = true;
							} else {
								System.out.println("Post not deleted.");
								task_completed = true;
							}
						}
					}
				} else {
					System.out.println("Request denied! You are not the owner of this post.");
					task_completed = true;
				}
			}
		}
		if (i == posts.size() && task_completed == false) {
			System.out.println("Invalid Post ID! Post not found.");
		}
	}

	public static void menu() {
		sc = new Scanner(System.in);
		int i;
		System.out.println("\nWelcome " + username);
		input_mismatch = false;

		do {
			System.out.println("** Student Menu **\n" + "1. New Event Post\n" + "2. New Sale Post\n"
					+ "3. New Job Post\n" + "4. Reply To Post\n" + "5. Display My Posts\n" + "6. Display All Posts\n"
					+ "7. Close Post\n" + "8. Delete Post\n" + "9. Log Out\n" + "Enter your choice: ");

			do {
				try {
					sc = new Scanner(System.in);
					menu_choice = sc.nextInt();
					input_mismatch = false;
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			switch (menu_choice) {
			case 1:
				// Create Event Post
				createNewPost(menu_choice);
				menu();
				break;

			case 2:
				// Create Sale Post
				createNewPost(menu_choice);
				menu();
				break;

			case 3:
				// Create Job Post
				createNewPost(menu_choice);
				menu();
				break;

			case 4:
				// Reply to posts
				replyPost();
				break;

			case 5:
				// Show my posts
				boolean task_completed = false;
				if (posts.isEmpty())
					System.out.println("No posts available.");
				else {
					System.out.println("----------Your Posts----------");
					for (i = 0; i < posts.size(); i++) {
						if (posts.get(i).getCreator_id().equals(username)) {
							System.out.println(posts.get(i).getReplyDetails() + "\n");
							task_completed = true;
							System.out.println("------------------------------------");
						}
					}
					if (i == posts.size() && !task_completed)
						System.out.println("You do not have any post of your own!");
				}
				break;

			case 6:
				// Show all post
				if (posts.isEmpty())
					System.out.println("No posts available in the system.");
				else {
					System.out.println("----------Posts Lists----------");
					for (i = 0; i < posts.size(); i++) {
						System.out.println(posts.get(i).getPostDetails());
						System.out.println("------------------------------------");
					}
				}
				break;

			case 7:
				// Close post
				closeDeletePost(menu_choice);
				break;

			case 8:
				// Delete post
				closeDeletePost(menu_choice);
				break;

			case 9:
				// Log out
				main_menu();
				menu_choice = 0;
				break;
			default:
				System.out.println("Invalid. Enter valid menu option");
			}
		} while ((menu_choice > 9)); 
	}

	public static void main_menu() {
		sc = new Scanner(System.in);

		System.out.println("WELCOME TO UNILINK");
		System.out.println("\t1. Login\n\t2. Quit");
		do {
			System.out.println("Enter your option: ");

			do {
				try {
					sc = new Scanner(System.in);
					main_choice = sc.nextInt();
					input_mismatch = false;
				} catch (Exception e) {
					System.out.println("Invalid input. Enter again: ");
					input_mismatch = true;
				}
			} while (input_mismatch);

			switch (main_choice) {
			case 1:
				// Log in
				do {
					System.out.println("Enter username: ");
					username = sc.next();
					if (!username.matches("s\\d+") && !username.matches("S\\d+"))
						System.out.println("\nInvalid username. Enter again\n");
				} while (!username.matches("s\\d+") && !username.matches("S\\d+"));
				menu();
				break;
			case 2:
				// Log out
				System.out.println("System exited! Thanks for using UniLink system");
				main_choice = 0;
				break;
			default:
				System.out.println("Invalid. Enter valid menu option");
			}
		} while ((main_choice > 2));
	}

}
