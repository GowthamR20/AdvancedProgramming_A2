import java.util.Collections;
import java.util.Comparator;

public class Job extends Post {

	private double proposed_price;
	private double lowest_offer;

	public Job(String id, String title, String description, String creator_id, String status, double proposed_price,
			double lowest_offer) {
		super(id, title, description, creator_id, status);
		setProposed_price(proposed_price);
		setLowest_offer(lowest_offer);
	}

	public String getPostDetails() {
		return super.getPostDetails() + "\nProposed price: $" + getProposed_price() + "\nLowest offer: $"
				+ getLowest_offer();
	}

	@Override
	public boolean handleReply(Reply reply) {
		if (getStatus().equals("OPEN")) {
			if (getLowest_offer() == 0 && reply.getValue() < getProposed_price()) {
				setLowest_offer(reply.getValue());
				super.setReplies(reply);
				return true;
			} else if (reply.getValue() < getLowest_offer() && reply.getValue() > 0) {
				setLowest_offer(reply.getValue());
				super.setReplies(reply);
				return true;
			} else  // if (reply.getValue() > getProposed_price())
				return false;
		} else
			return false;
	}

	@Override
	public String getReplyDetails() {
		Collections.sort(super.getReplies(), new Comparator<Reply>() {
			public int compare(Reply r1, Reply r2) {
				if (r1.getValue() == r2.getValue())
					return 0;
				else if (r1.getValue() > r2.getValue())
					return 1;
				else
					return -1;
			}
		});

		String replyDetails = getPostDetails() + "\nOffer History:\n";
		for (int i = 0; i < getReplies().size(); i++) {
			replyDetails += getReplies().get(i).getResponder_id() + ": $" + getReplies().get(i).getValue() + "\n";
		}
		return replyDetails;
	}

	public double getProposed_price() {
		return proposed_price;
	}

	public void setProposed_price(double proposed_price) {
		this.proposed_price = proposed_price;
	}

	public double getLowest_offer() {
		return lowest_offer;
	}

	public void setLowest_offer(double lowest_offer) {
		this.lowest_offer = lowest_offer;
	}

}
