
public class StartUP {

	public static void main(String[] args) {
		
		Unilink ul = new Unilink();
		
		// Hard-code Event Post
		ul.createNewPost(4);
		
		// Hard-code Sale Post
		ul.createNewPost(5);
		
		// Hard-code Job Post
		ul.createNewPost(6);
		
		// Starting Application
		ul.main_menu();
	}

}
