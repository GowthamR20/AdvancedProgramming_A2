import java.util.Collections;
import java.util.Comparator;

public class Sale extends Post {

	private double asking_price;
	private double highest_price;
	private double min_raise;

	public Sale(String id, String title, String description, String creator_id, String status, double asking_price,
			double min_raise) {
		super(id, title, description, creator_id, status);
		setAsking_price(asking_price);
		setMin_raise(min_raise);
		setHighest_price(0);
	}

	public String getPostDetails() {
		return super.getPostDetails() + "\nMinimum Raise: $" + getMin_raise() + "\nHighest Offer: $"
				+ getHighest_price();
	}

	@Override
	public boolean handleReply(Reply reply) {

		boolean isValid = false;

		if (reply.getValue() >= getHighest_price() + getMin_raise())
			isValid = true;
		if (isValid && (reply.getValue() < getAsking_price())) {
			super.setReplies(reply);
			setHighest_price(reply.getValue());
			return true;
		} else if (asking_price <= reply.getValue()) {
			super.setReplies(reply);
			setHighest_price(reply.getValue());
			setStatus("CLOSED");
			return true;
		} else
			return false;
	}

	@Override
	public String getReplyDetails() {
		Collections.sort(super.getReplies(), new Comparator<Reply>() {
			public int compare(Reply r1, Reply r2) {
				if (r1.getValue() == r2.getValue())
					return 0;
				else if (r1.getValue() < r2.getValue())
					return 1;
				else
					return -1;
			}
		});

		String replyDetails = getPostDetails() + "\nOffer History:\n";
		if (getReplies().isEmpty())
			replyDetails += replyDetails + " No Offer";

		for (int i = 0; i < getReplies().size(); i++) {
			replyDetails += getReplies().get(i).getResponder_id() + ": $" + getReplies().get(i).getValue() + "\n";
		}
		return replyDetails;
	}

	public double getAsking_price() {
		return asking_price;
	}

	public void setAsking_price(double asking_price) {
		this.asking_price = asking_price;
	}

	public double getMin_raise() {
		return min_raise;
	}

	public void setMin_raise(double min_raise) {
		this.min_raise = min_raise;
	}

	public double getHighest_price() {
		return highest_price;
	}

	public void setHighest_price(double highest_price) {
		this.highest_price = highest_price;
	}

}
